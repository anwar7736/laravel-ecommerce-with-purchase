  <!-- footer section start  -->
  <footer>
    <hr>
    <div class="container-fluid">
      <div class="row">
        <div class="mt-2 col-lg-4 col-md-12 col-12 border border-start-0 border-top-0 border-bottom-0">
          <div id="company" class="company">

            <ul style="list-style: none; padding: 10px;">
              <li class="text-cap pb-3"><h6><b>Company</b></h6></li>
              <li class="font-m-sm pt-2"><a href="<?php echo e(url('/about-us')); ?>" class="nav-link">About Us</a></li>
              <li class="font-m-sm pt-2"><a href="<?php echo e(url('/career')); ?>" class="nav-link">Careers</a></li>
              <li class="font-m-sm pt-2"><a href="#" class="nav-link">World of RL</a></li>
              <li class="font-m-sm pt-2"><a href="<?php echo e(url('/protecting-our-brands')); ?>" class="nav-link">Protecting Our Brands</a></li>
              <li class="font-m-sm pt-2"><a href="#" class="nav-link">Global Citizenship & Sustainability</a></li>
              <li class="font-m-sm pt-2"><a href="#" class="nav-link">Commitment to Racial Equity</a></li>
              <li class="font-m-sm pt-2"><a href="#" class="nav-link">COVID-19 Updates</a></li>
              <li class="font-m-sm pt-2"><a href="#" class="nav-link">Find a Store</a></li>
              <li class="font-m-sm pt-2"><a href="#" class="nav-link">Download the Ralph Lauren App</a></li>
            </ul>
          </div>
        </div>
        <div class="mt-2 col-lg-4 col-md-12 col-12 border border-start-0 border-top-0 border-bottom-0">
          <div id="account" class="account">

            <ul style="list-style: none; padding: 10px;">
              <li class="text-cap pb-3"><h6><b>ACCOUNT</b></h6></li>
              <li class="font-m-sm pt-2"><a href="#" class="nav-link">My Account</a></li>
              <li class="font-m-sm pt-2"><a href="#" class="nav-link">Create Account</a></li>
              <li class="font-m-sm pt-2"><a href="#" class="nav-link">Check Order Status</a></li>
              <li class="font-m-sm pt-2"><a href="#" class="nav-link">Order History</a></li>
              <li class="font-m-sm pt-2"><a href="#" class="nav-link">Returns & Exchanges</a></li>
            </ul>
          </div>
        </div>
        <div class="mt-2 col-lg-4 col-md-12 col-12 border border-start-0 border-top-0 border-bottom-0">
          <div id="customer-assistent" class="customer-assistent">

            <ul style="list-style: none; padding: 10px;">
              <li class="text-cap pb-3"><h6><b>CUSTOMER ASSISTANCE</b></h6></li>
              <li class="font-m-sm pt-2"><a href="#" class="nav-link">Live Chat</a></li>
              <li class="font-m-sm pt-2"><a href="#" class="nav-link">Customer Support</a></li>
              <li class="font-m-sm pt-2"><a href="#" class="nav-link">Shipping & Handling</a></li>
              <li class="font-m-sm pt-2"><a href="#" class="nav-link">Satisfaction Guarantee</a></li>
              <li class="font-m-sm pt-2"><a href="#" class="nav-link">Gift Cards</a></li>
              <li class="font-m-sm pt-2"><a href="#" class="nav-link">Mobile Marketing</a></li>
              <li class="font-m-sm pt-2"><a href="#" class="nav-link">Sitemap</a></li>
            </ul>
          </div>
        </div>
       
         
      </div>
    </div>
    <hr>
    <div class="p-3"></div>
    <hr>
    <div class="">
      <div class="row">
        <div class="col-lg col-12 text-center p-1"><a href="#" class="a-herf text-dark font-sm" style="font-size: 10px;">Company Information</a></div>
      <div class="col-lg col-12 text-center p-1"><a href="#" class="a-herf text-dark font-sm" style="font-size: 10px;">Terms of Use</a></div>
      <div class="col-lg col-12 text-center p-1"><a href="<?php echo e(url('/privacy-notice')); ?>" class="a-herf text-dark font-sm" style="font-size: 10px;">Privacy Notice</a></div>
      <div class="col-lg col-12 text-center p-1"><a href="#" class="a-herf text-dark font-sm" style="font-size: 10px;">UK and California Transparency Act</a></div>
      <div class="col-lg col-12 text-center p-1"><a href="#" class="a-herf text-dark font-sm" style="font-size: 10px;">Do Not Sell My Personal Information</a></div>
      </div>
    </div>
    <div class="text-center font-sm p-1">
      <div class="p-2 d-lg-block d-md-none d-none"></div>
      &copy;COPYRIGHT 2022 RALPH LAUREN MEDIA LLC
    </div>
  </footer>
  <!-- footer section end  --><?php /**PATH C:\xampp\htdocs\ecommerce\resources\views/frontend/partials/footer.blade.php ENDPATH**/ ?>