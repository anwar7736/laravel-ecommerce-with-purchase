    <!-- Header Start  -->
    <header class="header container-fluid p-0 sticky-top" id="header">

      <nav class="navbar navbar-expand-lg ps-3 pe-3" id="forwhitebg">
              <div class="navbar-toggler ma5menu__toggle ps-1 pt-1">
                <div class="bar1 bar"></div>
                <div class="bar2 bar"></div>
                <div style="display: none;">

                  <!-- source for mobile menu start -->
                  <ul class="site-menu">
                      <li class="ma5menu__leave btn btn-success" id="signupin"><a href="#"><span class="text-center">Sign In / Register</span> </a></li>
                      <li>
                          <a href="#">MEN</a>
                          <ul>
                              <li><a href="#">What's New</a>
                                  <ul>
                                    <li><a href="#">New Arrivels</a></li>
                                    <li><a href="#">US Open Tennis</a></li>
                                    <li><a href="#">Spectator Style</a></li>
                                    <li><a href="#">Heritage Icons</a></li>
                                    <li><a href="#">Fall Golf</a></li>
                                    <li><a href="#">Ralph's Club Parfum</a></li>
                                    <li><a href="#">Luxury Formalwear</a></li>
                                    <li><a href="#">Equestrian Icons</a></li>
                                    <li><a href="#">The Polo Bear Shop</a></li>
                                    <li><a href="#">Ralph Lauren Vintage</a></li>
                                    <li><a href="#">Explore My Style</a></li>
                                  </ul>
                              </li>
                              <li><a href="#">Clothing</a>
                                <ul>
                                  <li><a href="#">Polo Shirts</a></li>
                                  <li><a href="#">T-Shirts & Rugby Shirts</a></li>
                                  <li><a href="#">Casual Shirts & Dress Shirts</a></li>
                                  <li><a href="#">Sweatshirts & Sweatpants</a></li>
                                  <li><a href="#">Shorts & Swim Trunks</a></li>
                                  <li><a href="#">Jeans & Denim</a></li>
                                  <li><a href="#">Pants & Chinos</a></li>
                                  <li><a href="#">Sweaters</a></li>
                                  <li><a href="#">Jackets, Coats & Vests</a></li>
                                  <li><a href="#">Activewear</a></li>
                                  <li><a href="#">Sport Coats & Blazers</a></li>
                                  <li><a href="#">Suits & Tuxedos</a></li>
                                  <li><a href="#">Pajamas & Robes</a></li>
                                  <li><a href="#">Underwear & Undershirts</a></li>
                                </ul>
                              </li>
                              <li><a href="#">Big & Tall</a></li>
                              <li>
                                <a href="#">Shoes</a>
                                <ul>
                                  <li><a href="#">Sneakers</a></li>
                                  <li><a href="#">Slides & Slippers</a></li>
                                  <li><a href="#">Casual Shoes</a></li>
                                  <li><a href="#">Dress Shoes</a></li>
                                  <li><a href="#">Boots</a></li>
                                </ul>
                              </li>
                              <li>
                                  <a href="#">Accesories</a>
                                  <ul>
                                      <li><a href="#">Hats, Scarves & Gloves</a></li>
                                      <li><a href="#">Belts & Suspenders</a></li>
                                      <li><a href="#">Bags</a></li>
                                      <li><a href="#">Wallets & Accessories</a></li>
                                      <li><a href="#">Socks</a></li>
                                      <li><a href="#">Ties, Bow Ties & Pocket Squares</a></li>
                                      <li><a href="#">Fragrance</a></li>
                                      <li><a href="#">Sunglasses & Eyewear</a></li>
                                  </ul>
                              </li>
                              <li><a href="#">Watches</a></li>
                              <li>
                                <a href="#">Create Your Own</a>
                                <ul>
                                  <li><a href="#">Clothing</a></li>
                                  <li><a href="#">Accessories</a></li>
                                  <li><a href="#">Custom Outerwear</a></li>
                                  <li><a href="#">The Custom Polo, Made to Order</a></li>
                                </ul>
                              </li>
                              <li>
                                <a href="#">Our Brands</a>
                                <ul>
                                  <li><a href="#">Polo Ralph Lauren</a></li>
                                  <li><a href="#">RLX</a></li>
                                  <li><a href="#">Purple Label</a></li>
                                  <li><a href="#">Double RL</a></li>
                                  <li><a href="#">Pink Pony</a></li>
                                  <li><a href="#">Golf</a></li>
                                </ul>
                              </li>
                              <li>
                                <a href="#">Sale</a>
                                <ul>
                                  <li><a href="#">Clothing</a></li>
                                  <li><a href="#">Shoes</a></li>
                                  <li><a href="#">Accessories</a></li>
                                  <li><a href="#">Purple Label: Enjoy Up to 30% Off</a></li>
                                  <li><a href="#">Double RL: Enjoy Up to 30% Off</a></li>
                                  <li></li>
                                </ul>
                              </li>

                          </ul>
                      </li>
                      <li>
                          <a href="#">WOMEN</a>
                          <ul>
                              <li><a href="#">What's New</a>
                                  <ul>
                                    <li><a href="#">New Arrivels</a></li>
                                    <li><a href="#">US Open Tennis</a></li>
                                    <li><a href="#">Spectator Style</a></li>
                                    <li><a href="#">Heritage Icons</a></li>
                                    <li><a href="#">Fall Golf</a></li>
                                    <li><a href="#">Ralph's Club Parfum</a></li>
                                    <li><a href="#">Luxury Formalwear</a></li>
                                    <li><a href="#">Equestrian Icons</a></li>
                                    <li><a href="#">The Polo Bear Shop</a></li>
                                    <li><a href="#">Ralph Lauren Vintage</a></li>
                                    <li><a href="#">Explore My Style</a></li>
                                  </ul>
                              </li>
                              <li><a href="#">Clothing</a>
                                <ul>
                                  <li><a href="#">Polo Shirts</a></li>
                                  <li><a href="#">T-Shirts & Rugby Shirts</a></li>
                                  <li><a href="#">Casual Shirts & Dress Shirts</a></li>
                                  <li><a href="#">Sweatshirts & Sweatpants</a></li>
                                  <li><a href="#">Shorts & Swim Trunks</a></li>
                                  <li><a href="#">Jeans & Denim</a></li>
                                  <li><a href="#">Pants & Chinos</a></li>
                                  <li><a href="#">Sweaters</a></li>
                                  <li><a href="#">Jackets, Coats & Vests</a></li>
                                  <li><a href="#">Activewear</a></li>
                                  <li><a href="#">Sport Coats & Blazers</a></li>
                                  <li><a href="#">Suits & Tuxedos</a></li>
                                  <li><a href="#">Pajamas & Robes</a></li>
                                  <li><a href="#">Underwear & Undershirts</a></li>
                                </ul>
                              </li>
                              <li><a href="#">Big & Tall</a></li>
                              <li>
                                <a href="#">Shoes</a>
                                <ul>
                                  <li><a href="#">Sneakers</a></li>
                                  <li><a href="#">Slides & Slippers</a></li>
                                  <li><a href="#">Casual Shoes</a></li>
                                  <li><a href="#">Dress Shoes</a></li>
                                  <li><a href="#">Boots</a></li>
                                </ul>
                              </li>
                              <li>
                                  <a href="#">Accesories</a>
                                  <ul>
                                      <li><a href="#">Hats, Scarves & Gloves</a></li>
                                      <li><a href="#">Belts & Suspenders</a></li>
                                      <li><a href="#">Bags</a></li>
                                      <li><a href="#">Wallets & Accessories</a></li>
                                      <li><a href="#">Socks</a></li>
                                      <li><a href="#">Ties, Bow Ties & Pocket Squares</a></li>
                                      <li><a href="#">Fragrance</a></li>
                                      <li><a href="#">Sunglasses & Eyewear</a></li>
                                  </ul>
                              </li>
                              <li><a href="#">Watches</a></li>
                              <li>
                                <a href="#">Create Your Own</a>
                                <ul>
                                  <li><a href="#">Clothing</a></li>
                                  <li><a href="#">Accessories</a></li>
                                  <li><a href="#">Custom Outerwear</a></li>
                                  <li><a href="#">The Custom Polo, Made to Order</a></li>
                                </ul>
                              </li>
                              <li>
                                <a href="#">Our Brands</a>
                                <ul>
                                  <li><a href="#">Polo Ralph Lauren</a></li>
                                  <li><a href="#">RLX</a></li>
                                  <li><a href="#">Purple Label</a></li>
                                  <li><a href="#">Double RL</a></li>
                                  <li><a href="#">Pink Pony</a></li>
                                  <li><a href="#">Golf</a></li>
                                </ul>
                              </li>
                              <li>
                                <a href="#">Sale</a>
                                <ul>
                                  <li><a href="#">Clothing</a></li>
                                  <li><a href="#">Shoes</a></li>
                                  <li><a href="#">Accessories</a></li>
                                  <li><a href="#">Purple Label: Enjoy Up to 30% Off</a></li>
                                  <li><a href="#">Double RL: Enjoy Up to 30% Off</a></li>
                                  <li></li>
                                </ul>
                              </li>

                          </ul>
                      </li>
                      <li>
                          <a href="index-page.html">Lookbook</a>
                          <ul>
                              <li><a href="index-page.html">For business</a></li>
                              <li><a href="index-page.html">Premium Area</a></li>
                          </ul>
                      </li>
                      <li>
                          <a href="index-page.html">Campaigns</a>
                          <ul>
                              <li>
                                  <a href="index-page.html">Summer 2019</a>
                                  <ul>
                                      <li><a href="index-page.html">Winter 2018</a></li>
                                      <li><a href="index-page.html">Spring 2017</a></li>
                                  </ul>

                              </li>
                          </ul>
                      </li>
                      <li>
                          <a href="index-page.html">Brand</a>
                          <ul>
                              <li><a href="index-page.html">About us</a></li>
                              <li><a href="index-page.html">Press</a></li>
                          </ul>
                      </li>
                      <li><a href="index-page.html">Contact</a></li>
                  </ul>
                  <!-- source for mobile menu end -->

                  <!-- source for mobile menu footer start -->
                  <div id="ma5menu-tools" class="ma5menu__tools">
                      footer <a href="index-page.html">content</a> here
                  </div>
                  <!-- source for mobile menu footer end -->
              </div>
              </div>
              <a class="navbar-brand ps-2 m-0 serif" href="/">Ralph Lauren</a>
            <div class="collapse navbar-collapse" id="sidebar">
              <ul class="navbar-nav me-auto mb-2 mb-lg-0">
               <!-- <li class="nav-item row" id="men-hover">
                   <div class="nav-link col-12 d-lg-none d-md-block d-block tex-end" id="men-button">
                    <button class="border-0 border-rounded p-3 col-12 align-items-center row"><a href="#" class="ps-5 text-start a-herf text-dark col">MEN</a><i class="col text-end fa-solid fa-chevron-right"></i> </button>
                  </div> -->
                  <li class="nav-item justify-content-between" id="men-hover">
                  <a class="nav-link active dropdown1" aria-current="page" href="#" >MEN

                  </a>
                  <div class="dropdown dp-1 ps-5 pe-5" id="men-hover-dropdown">
                    <div class="row mt-5">
                        <div class="col">
                            <img class="col-12 banner-img" src="frontend/img/0816_flyout_men_dsk_no copy.jpg" alt="banner image">
                            <div class="banner-text">
                                <h2 class="serif white">Heritage Icon</h2>
                                <a href="#" class="u-botton text-light">Shop Now</a>
                            </div>
                        </div>
                        <div class="col dp-col">
                           <div class="ps-5">
                            <h5 class="serif">What's New</h5>
                            <br>
                            <a href="category.html">New Arrivels</a>
                            <a href="category.html">US Open Tennis</a>
                            <a href="category.html">Spectator Style</a>
                            <a href="category.html">Heritage Icons</a>
                            <a href="category.html">Fall Golf</a>
                            <a href="category.html">Ralph's Club Parfum</a>
                            <a href="category.html">Luxury Formalwear</a>
                            <a href="category.html">Equestrian Icons</a>
                            <a href="category.html">The Polo Bear Shop</a>
                            <a href="category.html">Ralph Lauren Vintage</a>
                            <a href="category.html">Explore My Style</a>
                           </div>
                        </div>
                        <div class="col dp-col">
                          <div class="ps-3">
                            <a href="#" class="ps-1 p-0"><h5 class="serif">Clothing</h5></a>
                            <br>
                            <a href="category.html">Polo Shirts</a>
                            <a href="category.html">T-Shirts & Rugby Shirts</a>
                            <a href="category.html">Casual Shirts & Dress Shirts</a>
                            <a href="category.html">Sweatshirts & Sweatpants</a>
                            <a href="category.html">Shorts & Swim Trunks</a>
                            <a href="category.html">Jeans & Denim</a>
                            <a href="category.html">Pants & Chinos</a>
                            <a href="category.html">Sweaters</a>
                            <a href="category.html">Jackets, Coats & Vests</a>
                            <a href="category.html">Activewear</a>
                            <a href="category.html">Sport Coats & Blazers</a>
                            <a href="category.html">Suits & Tuxedos</a>
                            <a href="category.html">Pajamas & Robes</a>
                            <a href="category.html">Underwear & Undershirts</a>

                           </div>

                          </div>
                        <div class="col dp-col">
                          <div class="ps-3">
                            <a href="#" class="ps-1 p-0"><h5 class="serif">Shoes</h5></a>
                            <br>
                            <a href="category.html">Sneakers</a>
                            <a href="category.html">Slides & Slippers</a>
                            <a href="category.html">Casual Shoes</a>
                            <a href="category.html">Dress Shoes</a>
                            <a href="category.html">Boots</a>
                           </div>
                           <div class="ps-3 pt-5">
                            <a href="category.html" class="ps-1"><h5 class="serif">Accessories</h5></a>
                            <br>
                            <a href="category.html">Hats, Scarves & Gloves</a>
                            <a href="category.html">Belts & Suspenders</a>
                            <a href="category.html">Bags</a>
                            <a href="category.html">Wallets & Accessories</a>
                            <a href="category.html">Socks</a>
                            <a href="category.html">Ties, Bow Ties & Pocket Squares</a>
                            <a href="category.html">Fragrance</a>
                            <a href="category.html">Sunglasses & Eyewear</a>
                           </div>
                           <div class="ps-3 pt-5">
                            <a href="#" class="ps-1"><h5 class="serif">Watches</h5></a>
                           </div>
                        </div>
                        <div class="col dp-col">
                          <div class="ps-3">
                            <a href="category.html" class="ps-1 p-0"><h5 class="serif">Create Your Own</h5></a>
                            <br>
                            <a href="category.html">Clothing</a>
                            <a href="category.html">Accessories</a>
                            <a href="category.html">Custom Outerwear</a>
                            <a href="category.html">The Custom Polo, Made to Order</a>

                           </div>

                           <div class="ps-3 pt-5">
                            <a href="category.html" class="ps-1 p-0"><h5 class="serif">Our Brands</h5></a>
                            <br>
                            <a href="category.html">Polo Ralph Lauren</a>
                            <a href="category.html">RLX</a>
                            <a href="category.html">Purple Label</a>
                            <a href="category.html">Double RL</a>
                            <a href="category.html">Pink Pony</a>
                            <a href="category.html">Golf</a>
                           </div>
                           <div class="ps-3 pt-5">
                            <a href="category.html" class="ps-1 p-0"><h5 class="serif">Sale</h5></a>
                            <br>
                            <a href="category.html">Clothing</a>
                            <a href="category.html">Shoes</a>
                            <a href="category.html">Accessories</a>
                            <a href="category.html">Purple Label: Enjoy Up to 30% Off</a>
                            <a href="category.html">Double RL: Enjoy Up to 30% Off</a>
                           </div>

                        </div>
                    </div>
                  </div>

                </li>

                  <li class="nav-item justify-content-between" id="women-hover">
                  <a class="nav-link active dropdown1" aria-current="page" href="#" >WOMEN

                  </a>
                  <div class="dropdown dp-1 ps-5 pe-5" id="women-hover-dropdown">
                    <div class="row mt-5">
                        <div class="col">
                            <img class="col-12 banner-img" src="frontend/img/0816_flyout_men_dsk_no copy.jpg" alt="banner image">
                            <div class="banner-text">
                                <h2 class="serif white">Heritage Icon</h2>
                                <a href="category.html" class="u-botton text-light">Shop Now</a>
                            </div>
                        </div>

                        <div class="col dp-col">
                           <div class="ps-5">
                            <h5 class="serif">What's New</h5>
                            <br>
                            <a href="category.html">New Arrivels</a>
                            <a href="category.html">US Open Tennis</a>
                            <a href="category.html">Spectator Style</a>
                            <a href="category.html">Heritage Icons</a>
                            <a href="category.html">Fall Golf</a>
                            <a href="category.html">Ralph's Club Parfum</a>
                            <a href="category.html">Luxury Formalwear</a>
                            <a href="category.html">Equestrian Icons</a>
                            <a href="category.html">The Polo Bear Shop</a>
                            <a href="category.html">Ralph Lauren Vintage</a>
                            <a href="category.html">Explore My Style</a>
                           </div>
                        </div>
                        <div class="col dp-col">
                          <div class="ps-3">
                            <a href="category.html" class="ps-1 p-0"><h5 class="serif">Clothing</h5></a>
                            <br>
                                <a href="category.html">Shirts & Blouses</a>
                                <a href="category.html">Sweaters</a>
                                <a href="category.html">Polo Shirts</a>
                                <a href="category.html">T-Shirts</a>
                                <a href="category.html">Sweatshirts & Sweatpants</a>
                                <a href="category.html">Jackets & Blazers</a>
                                <a href="category.html">Outerwear & Vests</a>
                                <a href="category.html">Pants</a>
                                <a href="category.html">Jeans</a>
                                <a href="category.html">Skirts</a>
                                <a href="category.html">Shorts</a>
                                <a href="category.html">Activewear</a>
                                <a href="category.html">Swimsuits & Cover-Ups</a>
                                <a href="category.html">Sleepwear</a>
                           </div>
                           <div class="ps-3 pt-5">
                             <a href="category.html" class="ps-1 p-0"><h5 class="serif">
                               Petite (Sizes 0–14)
                            </h5></a>
                          </div>
                           <div class="ps-3 pt-5">
                             <a href="category.html" class="ps-1 p-0"><h5 class="serif">
                               Woman (Sizes 14–22)
                            </h5></a>
                          </div>
                          </div>
                        <div class="col dp-col">
                          <div class="ps-3">
                            <a href="category.html" class="ps-1 p-0"><h5 class="serif">Shoes</h5></a>
                            <br>
                            <a href="category.html">Sneakers</a>
                            <a href="category.html">Slides & Slippers</a>
                            <a href="category.html">Casual Shoes</a>
                            <a href="category.html">Dress Shoes</a>
                            <a href="category.html">Boots</a>
                           </div>
                           <div class="ps-3 pt-5">
                            <a href="category.html" class="ps-1"><h5 class="serif">Accessories</h5></a>
                            <br>
                            <a href="category.html">Hats, Scarves & Gloves</a>
                            <a href="category.html">Belts & Suspenders</a>
                            <a href="category.html">Bags</a>
                            <a href="category.html">Wallets & Accessories</a>
                            <a href="category.html">Socks</a>
                            <a href="category.html">Ties, Bow Ties & Pocket Squares</a>
                            <a href="category.html">Fragrance</a>
                            <a href="category.html">Sunglasses & Eyewear</a>
                           </div>
                           <div class="ps-3 pt-5">
                            <a href="category.html" class="ps-1"><h5 class="serif">Watches</h5></a>
                           </div>
                        </div>
                        <div class="col dp-col">
                          <div class="ps-3">
                            <a href="category.html" class="ps-1 p-0"><h5 class="serif">Create Your Own</h5></a>
                            <br>
                            <a href="category.html">Clothing</a>
                            <a href="category.html">Accessories</a>
                            <a href="category.html">Custom Outerwear</a>
                            <a href="category.html">The Custom Polo, Made to Order</a>

                           </div>

                           <div class="ps-3 pt-5">
                            <a href="category.html" class="ps-1 p-0"><h5 class="serif">Our Brands</h5></a>
                            <br>
                            <a href="category.html">Polo Ralph Lauren</a>
                            <a href="category.html">RLX</a>
                            <a href="category.html">Purple Label</a>
                            <a href="category.html">Double RL</a>
                            <a href="category.html">Pink Pony</a>
                            <a href="category.html">Golf</a>
                           </div>
                           <div class="ps-3 pt-5">
                            <a href="category.html" class="ps-1 p-0"><h5 class="serif">Sale</h5></a>
                            <br>
                            <a href="category.html">Clothing</a>
                            <a href="category.html">Shoes</a>
                            <a href="category.html">Accessories</a>
                            <a href="category.html">Purple Label: Enjoy Up to 30% Off</a>
                            <a href="category.html">Double RL: Enjoy Up to 30% Off</a>
                           </div>

                        </div>
                    </div>
                  </div>


                </li>
                  <li class="nav-item justify-content-between" id="kidsandbaby">
                  <a class="nav-link active dropdown1" aria-current="page" href="#" >KIDS AND BABY

                  </a>
                  <div class="dropdown dp-2 ps-5 pe-5" id="women-hover-dropdown">
                    <div class="row mt-5">
                        <div class="col">
                            <img class="col-12 banner-img" src="frontend/img/0816_flyout_men_dsk_no copy.jpg" alt="banner image">
                            <div class="banner-text">
                                <h2 class="serif white">Heritage Icon</h2>
                                <a href="category.html" class="u-botton">Shop Now</a>
                            </div>
                        </div>
                        <div class="col dp-col">
                           <div class="ps-5">
                            <h5 class="serif">What's New</h5>
                            <br>
                            <a href="category.html">New Arrivels</a>
                            <a href="category.html">US Open Tennis</a>
                            <a href="category.html">Spectator Style</a>
                            <a href="category.html">Heritage Icons</a>
                            <a href="category.html">Fall Golf</a>
                            <a href="category.html">Ralph's Club Parfum</a>
                            <a href="category.html">Luxury Formalwear</a>
                            <a href="category.html">Equestrian Icons</a>
                            <a href="category.html">The Polo Bear Shop</a>
                            <a href="category.html">Ralph Lauren Vintage</a>
                            <a href="category.html">Explore My Style</a>
                           </div>
                        </div>
                        <div class="col dp-col">
                          <div class="ps-3">
                            <a href="category.html" class="ps-1 p-0"><h5 class="serif">Clothing</h5></a>
                            <br>
                                <a href="category.html">Shirts & Blouses</a>
                                <a href="category.html">Sweaters</a>
                                <a href="category.html">Polo Shirts</a>
                                <a href="category.html">T-Shirts</a>
                                <a href="category.html">Sweatshirts & Sweatpants</a>
                                <a href="category.html">Jackets & Blazers</a>
                                <a href="category.html">Outerwear & Vests</a>
                                <a href="category.html">Pants</a>
                                <a href="category.html">Jeans</a>
                                <a href="category.html">Skirts</a>
                                <a href="category.html">Shorts</a>
                                <a href="category.html">Activewear</a>
                                <a href="category.html">Swimsuits & Cover-Ups</a>
                                <a href="category.html">Sleepwear</a>
                           </div>
                           <div class="ps-3 pt-5">
                             <a href="category.html" class="ps-1 p-0"><h5 class="serif">
                               Petite (Sizes 0–14)
                            </h5></a>
                          </div>
                           <div class="ps-3 pt-5">
                             <a href="category.html" class="ps-1 p-0"><h5 class="serif">
                               Woman (Sizes 14–22)
                            </h5></a>
                          </div>
                          </div>
                        <div class="col dp-col">
                          <div class="ps-3">
                            <a href="category.html" class="ps-1 p-0"><h5 class="serif">Shoes</h5></a>
                            <br>
                            <a href="category.html">Sneakers</a>
                            <a href="category.html">Slides & Slippers</a>
                            <a href="category.html">Casual Shoes</a>
                            <a href="category.html">Dress Shoes</a>
                            <a href="category.html">Boots</a>
                           </div>
                           <div class="ps-3 pt-5">
                            <a href="category.html" class="ps-1"><h5 class="serif">Accessories</h5></a>
                            <br>
                            <a href="category.html">Hats, Scarves & Gloves</a>
                            <a href="category.html">Belts & Suspenders</a>
                            <a href="category.html">Bags</a>
                            <a href="category.html">Wallets & Accessories</a>
                            <a href="category.html">Socks</a>
                            <a href="category.html">Ties, Bow Ties & Pocket Squares</a>
                            <a href="category.html">Fragrance</a>
                            <a href="category.html">Sunglasses & Eyewear</a>
                           </div>
                           <div class="ps-3 pt-5">
                            <a href="category.html" class="ps-1"><h5 class="serif">Watches</h5></a>
                           </div>
                        </div>
                        <div class="col dp-col">
                          <div class="ps-3">
                            <a href="category.html" class="ps-1 p-0"><h5 class="serif">Create Your Own</h5></a>
                            <br>
                            <a href="category.html">Clothing</a>
                            <a href="category.html">Accessories</a>
                            <a href="category.html">Custom Outerwear</a>
                            <a href="category.html">The Custom Polo, Made to Order</a>

                           </div>

                           <div class="ps-3 pt-5">
                            <a href="category.html" class="ps-1 p-0"><h5 class="serif">Our Brands</h5></a>
                            <br>
                            <a href="category.html">Polo Ralph Lauren</a>
                            <a href="category.html">RLX</a>
                            <a href="category.html">Purple Label</a>
                            <a href="category.html">Double RL</a>
                            <a href="category.html">Pink Pony</a>
                            <a href="category.html">Golf</a>
                           </div>
                           <div class="ps-3 pt-5">
                            <a href="category.html" class="ps-1 p-0"><h5 class="serif">Sale</h5></a>
                            <br>
                            <a href="category.html">Clothing</a>
                            <a href="category.html">Shoes</a>
                            <a href="category.html">Accessories</a>
                            <a href="category.html">Purple Label: Enjoy Up to 30% Off</a>
                            <a href="category.html">Double RL: Enjoy Up to 30% Off</a>
                           </div>

                        </div>
                    </div>
                  </div>


                </li>
                  <li class="nav-item justify-content-between3" id="women-hover">
                  <a class="nav-link active dropdown1" aria-current="page" href="#" >HOME

                  </a>



                </li>
                  <li class="nav-item justify-content-between3" id="women-hover">
                  <a class="nav-link active dropdown1" aria-current="page" href="#" >GIFTS

                  </a>


                </li>
                  <li class="nav-item justify-content-between3" id="women-hover">
                  <a class="nav-link active dropdown1" aria-current="page" href="#" >WORLD OF RL

                  </a>



                </li>
                  <li class="nav-item justify-content-between3" id="women-hover">
                  <a class="nav-link active dropdown1" aria-current="page" href="#" >SELE

                  </a>



                </li>


              </ul>
              <!-- mobile menu toggle button end -->



            </div>
            <div class="icons">
              <ul class="d-flex align-items-center pe-1 ps-0">
                <li class="nav-link"><a href="#_" class="white search"><i class="fa-solid fa-magnifying-glass"></i></a></li>
                <li class="nav-link d-lg-block d-md-none d-none">
                  <a href="#" class="white "><i class="fa-regular fa-heart"></i></a></li>
                  <li class="nav-link d-lg-block d-md-none d-none signin-up">
                    <a href="signin.html" class="white" title="Sign In / Sign Up"><i class="fa-regular fa-user"></i></a>
                    <div class="signin-dp col-12 col-lg-3 ms-lg-auto m-auto p-3">
                      <div class="p-3"></div>
                      <div class="d-flex justify-content-between align-items-center">
                        <h2 class="serif">Sign In</h2>
                        <a href="signin.html" class="font-sm text-dark" style="text-decoration: underline;">Create An Account</a>
                      </div>
                      <form class="col-12">
                        <div class="form-floating mb-3">
                          <input type="email"
                          class="col-12 form-control" name="email" id="email" aria-describedby="email" placeholder="Enter Email Here">
                          <label for="email" class="form-label">Email</label>
                          <small id="email" class="form-text text-muted">* Required Field</small>
                        </div>
                        <div class="form-floating mb-3">
                          <input type="password" class="col-12 form-control" name="password" id="password" placeholder="Enter Password Here" aria-describedby="password">
                          <label for="password" class="form-label">Password</label>
                          <small id="password" class="form-text text-muted">* Required Field</small>
                        </div>
                        <div class="d-flex justify-content-between">
                          <a href="#" class="font-m-sm text-muted" style="text-decoration: underline;">Forgot Password</a>
                          <span class="text-muted font-m-sm">* Required</span>
                        </div>
                        <div class="mb-3 mt-3 form-check c-cursor">
                          <input type="checkbox" class="form-check-input" id="check1"/>
                          <label class="form-check-label text-muted" for="check1">Remember Me</label>
                        </div>
                        <button class="p-3 border col-12 mt-2" style="background-color: #041e3a; color: white;">Sign In</button>
                          <div  class="text-center">
                            <span>Or,</span>
                          </div>
                          <div class="row">
                            <div class="col-6">
                              <a href="#" class="font-m-sm d-flex btn border text-center">
                                <img src="frontend/img/google-logo-png-webinar-optimizing-for-success-google-business-webinar-13.png" alt="" width="20"> <span> Google</span>
                              </a>
                            </div>
                            <div class="col-6">
                              <a href="#" class="font-m-sm d-flex btn border text-center">
                                <img src="frontend/img/facebook-logo-icon-facebook-icon-png-images-icons-and-png-backgrounds-1.png" alt="" width="20"> <span> Facebook</span>
                              </a>
                            </div>
                          </div>
                      </form>
                    </div>
                  </li>
                <li class="nav-link">

                  <a href="#?" class="white" id="cart-sidebar-btn"><i class="fa fa-bag-shopping"></i></a></li>
              </ul>
            </div>
            <div class="search-wiget">
              <div class="text-end d-lg-none d-md-none d-block p-3"><button class="btn close-search"><i class="fa-solid fa-xmark"></i></button></div>
              <div class="container">
                <div class="pt-5 d-lg-block d-md-none d-none">
                </div>

                <div class="search-form">
                  <div class="input-group">
                    <span class="input-group-text" id="input1"><i class="fa-solid fa-magnifying-glass"></i></span>
                    <input type="text" class="form-control" aria-describedby="input1" placeholder="Search"/>
                  </div>
                  <div class="pt-3 d-lg-block d-md-none d-none">
                  </div>
                  <div class="row justify-content-between pt-5 pb-5">
                    <p class="col-12 col-md-12 col-lg-3"><b>
                      Tranding Search:
                    </b></p>
                    <div class="col-12 col-md-12 col-lg-9 row">
                      <a href="#" class="text-dark a-herf col-lg col-12"><i class="fa-solid fa-magnifying-glass"></i> <span class="ps-2">Polo Shirt</span></a>
                    <a href="#" class="text-dark a-herf col-lg col-12"><i class="fa-solid fa-magnifying-glass"></i> <span class="ps-2">Bears</span></a>
                    <a href="#" class="text-dark a-herf col-lg col-12 "><i class="fa-solid fa-magnifying-glass"></i> <span class="ps-2">Jackets</span></a>
                    <a href="#" class="text-dark a-herf col-lg col-12"><i class="fa-solid fa-magnifying-glass"></i> <span class="ps-2">Hoodies</span></a>
                    </div>
                    </div>
                    <div class="row mb-5">
                      <h3 class="serif">Popular Categories</h3>
                      <div class="col-lg-3 col-md-4">
                        <img src="frontend/img/categories img.jpg" alt="" class="col-12">
                        <div class="search-form-popular">
                          <h5 class="serif">Casual Shirts</h5>
                          <a href="category.html" class="text-light font-sm">MEN</a>
                        </div>
                      </div>
                      <div class="col-lg-3 col-md-4">
                        <img src="frontend/img/categories img.jpg" alt="" class="col-12">
                        <div class="search-form-popular">
                          <h5 class="serif">Casual Shirts</h5>
                          <a href="category.html" class="text-light font-sm">MEN</a>
                        </div>
                      </div>
                      <div class="col-lg-3 col-md-4">
                        <img src="frontend/img/categories img.jpg" alt="" class="col-12">
                        <div class="search-form-popular">
                          <h5 class="serif">Casual Shirts</h5>
                          <a href="category.html" class="text-light font-sm">MEN</a>
                        </div>
                      </div>
                      <div class="col-lg-3 col-md-4">
                        <img src="frontend/img/categories img.jpg" alt="" class="col-12">
                        <div class="search-form-popular">
                          <h5 class="serif">Casual Shirts</h5>
                          <a href="category.html" class="text-light font-sm">MEN</a>
                        </div>
                      </div>
                    </div>
                </div>
              </div>
            </div>
        </nav>

  </header><?php /**PATH C:\xampp\htdocs\ecommerce\resources\views/frontend/partials/navbar.blade.php ENDPATH**/ ?>