<!DOCTYPE html>
<html lang="en">
<?php echo $__env->make('frontend.partials.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<body>

    <div class="main-wrapper container-fluid">
      <!-- Header Start  -->
    <header class="header container-fluid p-0 sticky-top" id="header">

        <?php echo $__env->make('frontend.partials.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  
    </header>
    
    <!-- Header end  -->
    <div class="overlay-sidebar"></div>
    
    <?php echo $__env->make('frontend.partials.cart_sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('content'); ?>
    <!-- footer section start  -->
    <footer>
      <hr>
      <?php echo $__env->make('frontend.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <hr>
      
    </footer>
    </div>
    <!-- footer section end  -->
    <?php echo $__env->make('frontend.partials.js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\ecommerce\resources\views/frontend/app.blade.php ENDPATH**/ ?>